#!/bin/bash

timeout 1500 qemu-system-x86_64 \
    -m 512M \
    -kernel ./bzImage \
    -initrd ./rootfs.cpio \
    -append "root=/dev/ram rw console=ttyS0 oops=panic panic=1 quiet nokaslr nopti nosmep nosmap" \
    -netdev user,id=t0 -device e1000,netdev=t0,id=nic0 \
    -nographic \
    -monitor /dev/null \
    -cpu qemu64 \
    -no-reboot