#!/bin/bash

timeout 1500 qemu-system-x86_64 \
    -m 512M \
    -kernel ./bzImage \
    -initrd ./rootfs.cpio \
    -append "root=/dev/ram rw console=ttyS0 oops=panic panic=1 quiet nokaslr nopti nosmap" \
    -nographic \
    -cpu qemu64,+smep \
    -no-reboot